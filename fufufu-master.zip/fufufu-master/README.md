# GOJEKHEMAT
<br>Install termux di Playstore
<br>Ketik :
<br>pkg update && upgrade
<br>pkg install git
<br>pkg install php
<br>git clone https://github.com/herutok/GOJEKHEMAT.git
<br>cd GOJEKHEMAT

<br>Untuk Menjalankan Script :
<br>php herutok.php

<br>Untuk proses selanjutnya cukup ketik:
<br>cd GOJEKHEMAT
<br>php herutok.php
